Uer Location App
-----------------------------------

Odoo Version : Odoo 13.0 Community


Installation 
-------------------------------------
Install the Application => Apps -> Multiple Cancel Journal Entries(mass_cancel_journal_entries)


Overview
-------------------------------------
* Invoicing > Accounting > Journal Entries.
* This module will allows users cancel multiple journal entries from the tree view.
* Set boolean "Allow Cancelling Entries" true from account journal for deleting journal entries.